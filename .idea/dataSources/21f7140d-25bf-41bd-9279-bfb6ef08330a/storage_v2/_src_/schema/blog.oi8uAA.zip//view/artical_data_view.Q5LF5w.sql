create view artical_data_view as
select `c`.`id`              AS `cid`,
       `c`.`user_id`         AS `cuid`,
       `c`.`artical_id`      AS `artical_id`,
       `c`.`content`         AS `ccontent`,
       `c`.`time`            AS `ctime`,
       `c`.`is_delete`       AS `cdelete`,
       `u`.`id`              AS `uid`,
       `u`.`username`        AS `username`,
       `u`.`password`        AS `password`,
       `u`.`email`           AS `email`,
       `u`.`is_applied`      AS `is_applied`,
       `u`.`is_delete`       AS `udelete`,
       `u`.`is_profile`      AS `is_profile`,
       `a`.`id`              AS `aid`,
       `a`.`title`           AS `title`,
       `a`.`user_id`         AS `user_id`,
       `a`.`sys_category_id` AS `sys_category_id`,
       `a`.`category_id`     AS `category_id`,
       `a`.`content`         AS `acontent`,
       `a`.`summary`         AS `summary`,
       `a`.`publish_time`    AS `atime`,
       `a`.`is_top`          AS `is_top`,
       `a`.`is_delete`       AS `is_delete`
from ((`blog`.`comment` `c` join `blog`.`user` `u`)
         join `blog`.`article` `a`)
where ((`c`.`is_delete` = 0) and (`u`.`id` = `c`.`user_id`) and (`a`.`id` = `c`.`artical_id`));

